Build in comman_line file manager using CPP
